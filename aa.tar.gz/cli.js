#!/usr/bin/env node

const readline = require("readline");

const { exec } = require("child_process");

const GO_PATH = "/home/container/go/go/bin/go"; // Path ke Go

const rl = readline.createInterface({

    input: process.stdin,

    output: process.stdout,

    prompt: "[liberal@keg] ~$ " // Custom shell prompt

});

// Fungsi buat eksekusi command

function runCommand(command) {

    const args = command.trim().split(" "); // Pisah command & args

    if (args[0] === "exit") {

        console.log("Bye! 😼");

        rl.close();

        return;

    }

    // Deteksi kalau user input "go", pakai path Go yang benar

    if (args[0] === "go") {

        command = `${GO_PATH} ${args.slice(1).join(" ")}`;

    }

    exec(command, (error, stdout, stderr) => {

        if (error) {

            console.error(`❌ Error: ${stderr.trim()}`);

        } else {

            console.log(stdout.trim());

        }

        rl.prompt();

    });

}

// Mulai shell custom

console.log("🔥 Welcome to Pterodactyl Shell 😼 (type 'exit' to quit)");

rl.prompt();

rl.on("line", (line) => {

    runCommand(line);

}).on("close", () => {

    console.log("Session closed.");

    process.exit(0);

});