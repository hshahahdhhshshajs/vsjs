const { execSync } = require("child_process");

const fs = require("fs");

const goPath = "/home/container/go"; // Lokasi Golang

function installGo() {

    console.log("🚀 Downloading latest Go...");

    execSync(`curl -L https://go.dev/dl/go1.21.5.linux-amd64.tar.gz -o go.tar.gz`, { stdio: "inherit" });

    console.log("📦 Extracting Go...");

    execSync(`rm -rf ${goPath} && mkdir -p ${goPath} && tar -C ${goPath} -xzf go.tar.gz`, { stdio: "inherit" });

    console.log("⚙️ Setting up PATH...");

    const profilePath = "/home/container/.profile";

    fs.appendFileSync(profilePath, `\nexport PATH=$PATH:${goPath}/go/bin\n`);

    

    console.log("✅ Go installed successfully! Please restart your shell.");

}

// Verifikasi instalasi

function verifyInstallation() {

    try {

        const goVersion = execSync(`${goPath}/go/bin/go version`).toString();

        console.log(`🎉 Golang Installed: ${goVersion}`);

    } catch (error) {

        console.error("❌ Golang installation failed!");

        process.exit(1);

    }

}

// Eksekusi

installGo();

console.log("🔄 Restart shell atau logout & login ulang untuk apply PATH.");